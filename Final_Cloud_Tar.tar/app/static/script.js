'use strict';

window.addEventListener('load', function () {

  

});